//---------------------------------------------------------------------------

#ifndef Unit3H
#define Unit3H
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <ComCtrls.hpp>
#include "TSocket.h"
//---------------------------------------------------------------------------
class RecvThread : public TThread
{            
private:
       TSocket* sock;
protected:
        void __fastcall Execute();
public:
        __fastcall RecvThread(bool CreateSuspended);
public:
        TImage* img;
        String RemoteAddress;
        int srvport;
        TStatusBar *stat;
        int listentime;

};

//---------------------------------------------------------------------------
#endif
