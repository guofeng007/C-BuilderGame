//---------------------------------------------------------------------
#include <vcl.h>
#pragma hdrstop

#include "Unit4.h"
//--------------------------------------------------------------------- 
#pragma resource "*.dfm"
TOKBottomDlg *OKBottomDlg;
//---------------------------------------------------------------------
__fastcall TOKBottomDlg::TOKBottomDlg(TComponent* AOwner)
	: TForm(AOwner)
{
}
//---------------------------------------------------------------------

void __fastcall TOKBottomDlg::FormShow(TObject *Sender)
{
   this->Caption="���ڱ�����";
   this->lbl1->Font->Color=clBlue;
   this->lbl1->Caption="       �����ҵĲ���    ";
}
//---------------------------------------------------------------------------


void __fastcall TOKBottomDlg::FormPaint(TObject *Sender)
{
  TRect rect=Rect(50,20,300,400);
  Canvas->Font->Color=clGray;
  Canvas->Font->Name="΢���ź�";
  Canvas->Font->Size=13;
  DrawTextA(Canvas->Handle,"\a ���� 2011-1-15   ",sizeof("����-2011-1-15  "),
            &rect,DT_LEFT);
}
//---------------------------------------------------------------------------

void __fastcall TOKBottomDlg::lbl1Click(TObject *Sender)
{
ShellExecute(NULL,"open","http://blog.csdn.net/qq752923276",NULL,NULL,SW_SHOWNORMAL);
}
//---------------------------------------------------------------------------

