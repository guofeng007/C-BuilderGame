//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop

#include "Unit2.h"
#include "Unit1.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TForm2 *Form2;
//---------------------------------------------------------------------------
__fastcall TForm2::TForm2(TComponent* Owner)
        : TForm(Owner)
{
}
//---------------------------------------------------------------------------

void __fastcall TForm2::btn1Click(TObject *Sender)
{
   if(this->edt1->Text==""||this->edt2->Text=="")
   {
       Application->MessageBoxA("�����IP���˿ںŲ���Ϊ��","��ʾ",MB_ICONWARNING);
       return ;
   }
   if(this->edt1->Text!=Form1->srvaddr)
   {
      Form1->srvaddr=this->edt1->Text;
   }
   if(this->edt2->Text!=IntToStr(Form1->srvport))
   {
      Form1->srvport=StrToInt(this->edt2->Text);
   }
   this->Close();
}
//---------------------------------------------------------------------------
void __fastcall TForm2::btn2Click(TObject *Sender)
{
  this->Close();
}
//---------------------------------------------------------------------------
