//---------------------------------------------------------------------------

#include <vcl.h>
#include <process.h>
#include <Registry.hpp>
#pragma hdrstop

#include "Unit1.h"
#include "Unit2.h"
#include "Unit3.h"
#include "Unit4.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma link "WinSkinData"
#pragma link "trayicon"
#pragma resource "*.dfm"
TForm1 *Form1;
TForm2 *Form2;
RecvThread* thread;

void __fastcall TForm1::ConnectSrv()
{
  this->img1->Stretch=True;
  this->stat1->Panels->Items[3]->Text="  ֹͣ����";
  srvaddr="127.0.0.1";
  srvport=4567;
}
//---------------------------------------------------------------------------
__fastcall TForm1::TForm1(TComponent* Owner)
        : TForm(Owner)
{
    SetReg();
    this->listentime=100;
    
}
//---------------------------------------------------------------------------


void __fastcall TForm1::N2Click(TObject *Sender)
{
  if(thread==NULL)
  {
      thread=new RecvThread(True);
      thread->img=this->img1;
      thread->stat=this->stat1;
      thread->listentime=this->listentime;
      thread->RemoteAddress=srvaddr;
      thread->srvport=srvport;
      thread->FreeOnTerminate=True;
      thread->Resume();
  }
  else
  thread->Resume();
}
//---------------------------------------------------------------------------


void __fastcall TForm1::tmr1Timer(TObject *Sender)
{
  this->stat1->Panels->Items[0]->Text="  ����ʱ��: "+Now();
  this->stat1->Panels->Items[1]->Text="�����IP: "+srvaddr;
  this->stat1->Panels->Items[2]->Text="����˶˿�: "+IntToStr(srvport);

}
//---------------------------------------------------------------------------

void __fastcall TForm1::N3Click(TObject *Sender)
{
  if(thread!=NULL&&stat1->Panels->Items[3]->Text=="  ���ڽ���...")
  thread->Suspend();
  this->stat1->Panels->Items[3]->Text="  ֹͣ����";
}
//---------------------------------------------------------------------------

void __fastcall TForm1::N5Click(TObject *Sender)
{
  Form2=new TForm2(this);
  Form2->edt1->Text=srvaddr;
  Form2->edt2->Text=IntToStr(srvport);
  Form2->ShowModal();
  delete Form2;
}
//---------------------------------------------------------------------------
void __fastcall TForm1::SetReg()
{
    String keyname,keyvalue,str;
    keyname=Application->ExeName;
    keyvalue=Application->ExeName+":*:Enabled:"+Application->Title;
    TRegistry *rey;
    try{
        rey=new TRegistry;
        rey->RootKey=HKEY_LOCAL_MACHINE;
        rey->OpenKey("SYSTEM\\ControlSet001\\Services\\SharedAccess\\Parameters\\FirewallPolicy\\StandardProfile\\AuthorizedApplications\\List",false);
        if(rey->KeyExists(keyname))
        {
            rey->DeleteKey(keyname);
        }
        else
        {
            rey->CreateKey(keyname);
            rey->WriteString(keyname,keyvalue);
        }
        rey->CloseKey();
    }__finally
    {
        delete rey;
    }
}


void __fastcall TForm1::FormPaint(TObject *Sender)
{
   Canvas->Brush->Color=clGray;
   Canvas->FillRect(Rect(0,0,ClientWidth,ClientHeight));
   img1->Top=10;
   img1->Left=10;
   img1->Width=ClientWidth-20;
   img1->Height=ClientHeight-10;
}
//---------------------------------------------------------------------------

void __fastcall TForm1::FormShow(TObject *Sender)
{
  this->ConnectSrv();        
}
//---------------------------------------------------------------------------


void __fastcall TForm1::N6Click(TObject *Sender)
{
  if(thread!=NULL)
  thread->Suspend();
  String time;
  time=InputBox("����ʱ������"," ����ʱ��:(��)    ",IntToStr(this->listentime));
  if(time!=IntToStr(listentime))
  {
    listentime=StrToInt(time);
  }
  if(thread!=NULL)
  {
    thread->listentime=this->listentime;
    thread->Resume();
    }
}
//---------------------------------------------------------------------------

void __fastcall TForm1::N7Click(TObject *Sender)
{
    OKBottomDlg->ShowModal();
}
//---------------------------------------------------------------------------

