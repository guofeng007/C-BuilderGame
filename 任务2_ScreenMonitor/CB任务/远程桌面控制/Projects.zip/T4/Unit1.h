//---------------------------------------------------------------------------

#ifndef Unit1H
#define Unit1H
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <ExtCtrls.hpp>
#include <Menus.hpp>
#include <ComCtrls.hpp>
#include <winsock2.h>
#include "WinSkinData.hpp"
#include "trayicon.h"
#include <ImgList.hpp>


//---------------------------------------------------------------------------
class TForm1 : public TForm
{
__published:	// IDE-managed Components
        TImage *img1;
        TMainMenu *mm1;
        TMenuItem *N1;
        TMenuItem *N2;
        TMenuItem *N3;
        TMenuItem *N4;
        TMenuItem *N5;
        TStatusBar *stat1;
        TTimer *tmr1;
        TSkinData *SkinData1;
        TTrayIcon *TrayIcon1;
        TImageList *il1;
        TMenuItem *N6;
        TMenuItem *N7;
        void __fastcall N2Click(TObject *Sender);
        void __fastcall tmr1Timer(TObject *Sender);
        void __fastcall N3Click(TObject *Sender);
        void __fastcall N5Click(TObject *Sender);
        void __fastcall FormPaint(TObject *Sender);
        void __fastcall FormShow(TObject *Sender);
        void __fastcall N6Click(TObject *Sender);
        void __fastcall N7Click(TObject *Sender);
private:	// User declarations

public:		// User declarations
        __fastcall TForm1(TComponent* Owner);
        void __fastcall SetReg();
        void __fastcall ConnectSrv();
public:
        int srvport;
        String srvaddr;
        int listentime;
};
//---------------------------------------------------------------------------
extern PACKAGE TForm1 *Form1;

//---------------------------------------------------------------------------
#endif
