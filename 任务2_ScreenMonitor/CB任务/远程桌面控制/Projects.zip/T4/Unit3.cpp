//---------------------------------------------------------------------------

#include <vcl.h>
#include <jpeg.hpp>
#pragma hdrstop

#include "Unit3.h"


#pragma package(smart_init)
//---------------------------------------------------------------------------

//   Important: Methods and properties of objects in VCL can only be
//   used in a method called using Synchronize, for example:
//
//      Synchronize(UpdateCaption);
//
//   where UpdateCaption could look like:
//
//      void __fastcall RecvThread::UpdateCaption()
//      {
//        Form1->Caption = "Updated in a thread";
//      }
//---------------------------------------------------------------------------

__fastcall RecvThread::RecvThread(bool CreateSuspended)
        : TThread(CreateSuspended)
{
    sock=new TSocket;

}
//---------------------------------------------------------------------------
void __fastcall RecvThread::Execute()
{
        //---- Place thread code here ----
           u_short RecvPort=0;

          TMemoryStream *Stream;
          for(int i=1;i<=listentime;i++) //����ѭ�������ϻ��Զ������ͼ��
          {

            try{

                   // ����һ���������������ڴ�
                   Stream = new TMemoryStream;
                   TJPEGImage *jpeg;

               try{

                      jpeg = new TJPEGImage;

                      int RecvSocket = sock->BindSocket(&RecvPort);
                      if (RecvSocket)
                      {
                          AnsiString Msg = IntToStr(RecvPort) + "\n";
                          if (sock->SendMsg(RemoteAddress,srvport,Msg))
                          {
                                      // ��ʼ����ͼ����������
                                     if (sock->RecvStream(RecvSocket,Stream))
                                     {
                                             // ��������������ͼ��
                                             jpeg->LoadFromStream(Stream);
                                             stat->Panels->Items[3]->Text="  ���ڽ���...";
                                             img->Picture->Bitmap->Assign(jpeg);
                                             MessageBeep(MB_OK);  // ������ʾ����

                                     }
                                     else
                                       MessageBox(0,"����������ʧ��","EagleEye",MB_ICONERROR);
                          }
                          else
                          {
                                MessageBox(0,("�޷�������'"+ RemoteAddress +"'��������").c_str(),"��ʾ",MB_ICONERROR);
                                stat->Panels->Items[3]->Text="  ֹͣ����";
                                break;
                          }

                      }
                      else
                      {
                            MessageBox(0,"����˿�ʧ�ܣ��޷�������������","��ʾ",MB_ICONERROR);
                      }
                  }
                  __finally
                  {
                       delete jpeg;  // �ͷ���Դ
                      }

              }

           __finally {
             delete Stream;  // �ͷ���Դ
             }
            RecvPort+=1;

          }
          stat->Panels->Items[3]->Text="  ֹͣ����";
}
//---------------------------------------------------------------------------
