//----------------------------------------------------------------------------
#ifndef Unit2H
#define Unit2H
//----------------------------------------------------------------------------
#include <OKCANCL1.h>
#include <vcl\ExtCtrls.hpp>
#include <vcl\Buttons.hpp>
#include <vcl\StdCtrls.hpp>
#include <vcl\Controls.hpp>
#include <vcl\Forms.hpp>
#include <vcl\Graphics.hpp>
#include <vcl\Classes.hpp>
#include <vcl\SysUtils.hpp>
#include <vcl\Windows.hpp>
#include <vcl\System.hpp>
#include "okcancl1.h"
//----------------------------------------------------------------------------
class TOKHelpBottomDlg : public TOKBottomDlg
{
__published:
        TLabel *lbl1;
        TImage *img1;
        void __fastcall OKBtnClick(TObject *Sender);
        void __fastcall CancelBtnClick(TObject *Sender);
        void __fastcall FormShow(TObject *Sender);
        void __fastcall lbl1Click(TObject *Sender);
        void __fastcall FormPaint(TObject *Sender);
private:
public:
	virtual __fastcall TOKHelpBottomDlg(TComponent* AOwner);
};
//----------------------------------------------------------------------------
extern PACKAGE TOKHelpBottomDlg *OKHelpBottomDlg;
//----------------------------------------------------------------------------
#endif    
