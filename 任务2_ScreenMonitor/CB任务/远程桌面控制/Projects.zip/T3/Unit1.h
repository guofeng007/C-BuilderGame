//---------------------------------------------------------------------------

#ifndef Unit1H
#define Unit1H
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <ScktComp.hpp>
#include "TSocket.h"
#include <ExtCtrls.hpp>
#include "trayicon.h"
#include <ImgList.hpp>
#include <Menus.hpp>
#include "WinSkinData.hpp"
//---------------------------------------------------------------------------
class TForm1 : public TForm
{
__published:	// IDE-managed Components
        TServerSocket *srvrsckt1;
        TTrayIcon *TrayIcon1;
        TImageList *il1;
        TPopupMenu *pm1;
        TMenuItem *N1;
        TSkinData *SkinData1;
        TTimer *tmr1;
        TButton *btn1;
        TButton *btn2;
        void __fastcall srvrsckt1ClientRead(TObject *Sender,
          TCustomWinSocket *Socket);
        void __fastcall FormClose(TObject *Sender, TCloseAction &Action);
        void __fastcall FormShow(TObject *Sender);
        void __fastcall N1Click(TObject *Sender);
        void __fastcall btn2Click(TObject *Sender);
        void __fastcall btn1Click(TObject *Sender);
private:	// User declarations
        TSocket* sock;
        
public:		// User declarations
        __fastcall TForm1(TComponent* Owner);
        void __fastcall SetReg();
        void __fastcall Listen();

};
//---------------------------------------------------------------------------
extern PACKAGE TForm1 *Form1;
//---------------------------------------------------------------------------
#endif
