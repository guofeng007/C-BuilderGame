//---------------------------------------------------------------------------

#ifndef cmd_socket_H
#define cmd_socket_H
#include <winsock.h>
#include <windows.h>
#include <vcl.h>
#include <mem.h>
#include <sys\stat.h>
#include <math.h>

//---------------------------------------------------------------------------
#define PACKAGESIZE 4096
#define STREAMPORT  2000
class __declspec(dllexport) __stdcall TSocket
{
private:
     int svr_port;
public:
     TSocket()
     {
         WSAData wsaData;
         if ( WSAStartup(MAKEWORD(2,2), &wsaData) != 0 )
         {
             throw Exception("����WinSock����");
         }
     }
     ~TSocket()
     {
         WSACleanup();
     }
     int Connect_Server(AnsiString host, u_short port);
     int Write_Socket(int sockfd, AnsiString s);
     AnsiString Socket_Readln(int sockfd);
     BOOL SendMsg(AnsiString addr, u_short port, AnsiString msg);
     SOCKET BindSocket(u_short* port);
     BOOL SendStream(AnsiString addr, u_short port, TMemoryStream* Stream);
     BOOL RecvStream(SOCKET s, TMemoryStream* Stream);
};
#endif
 