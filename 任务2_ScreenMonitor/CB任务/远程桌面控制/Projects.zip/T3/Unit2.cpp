//---------------------------------------------------------------------
#include <vcl.h>
#pragma hdrstop

#include "Unit2.h"
//---------------------------------------------------------------------
#pragma link "okcancl1"
#pragma resource "*.dfm"
TOKHelpBottomDlg *OKHelpBottomDlg;
//--------------------------------------------------------------------- 
__fastcall TOKHelpBottomDlg::TOKHelpBottomDlg(TComponent* AOwner)
	: TOKBottomDlg(AOwner)
{
}
//--------------------------------------------------------------------- 
void __fastcall TOKHelpBottomDlg::OKBtnClick(TObject *Sender)
{
  this->Close();
}
//---------------------------------------------------------------------------

void __fastcall TOKHelpBottomDlg::CancelBtnClick(TObject *Sender)
{
  this->Close();
}
//---------------------------------------------------------------------------

void __fastcall TOKHelpBottomDlg::FormShow(TObject *Sender)
{
  
  this->Caption="���ڱ�����";
  this->lbl1->Font->Color=clBlue;
  this->lbl1->Caption="   �����ҵĲ���     ";
}
//---------------------------------------------------------------------------

void __fastcall TOKHelpBottomDlg::lbl1Click(TObject *Sender)
{
 ShellExecute(NULL,"open","http://blog.csdn.net/qq752923276",NULL,NULL,SW_SHOWNORMAL);        
}
//---------------------------------------------------------------------------


void __fastcall TOKHelpBottomDlg::FormPaint(TObject *Sender)
{
  TRect rect=Rect(70,20,300,400);
  Canvas->Font->Color=clGray;
  Canvas->Font->Name="΢���ź�";
  Canvas->Font->Size=14;
  DrawTextA(Canvas->Handle,"\a ���� 2011-1-15   ",sizeof("����-2011-1-15  "),
            &rect,DT_LEFT);
}
//---------------------------------------------------------------------------

